# 自动化测试生成器

一个专业的自动化测试代码生成工具，支持前端功能测试、后端API集成测试和单元测试的自动生成。

## 功能特性

### 🎯 三种测试类型
- **前端功能测试** - 基于 Selenium WebDriver 的浏览器自动化测试
- **后端API集成测试** - 基于 TestRestTemplate 的 HTTP 接口测试
- **控制器单元测试** - 基于 MockMvc 的 MVC 层测试

### ✨ 核心能力
- 自动分析业务代码结构
- 智能生成测试用例（正常、边界、异常场景）
- 生成完整的测试配置和数据准备脚本
- 生成可独立执行的测试报告
- 支持交互式和自动登录两种模式

## 快速开始

### 1. 环境准备

#### 必需软件
- JDK 8+
- Maven 3.6+
- Eclipse/IntelliJ IDEA
- MySQL 5.7+（用于测试数据库）
- Edge/Chrome/Firefox 浏览器（用于前端测试）

#### Maven 依赖
测试生成器会自动添加以下依赖到 `pom.xml`：

```xml
<!-- Spring Boot 测试 -->
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-test</artifactId>
    <scope>test</scope>
</dependency>

<!-- Selenium WebDriver -->
<dependency>
    <groupId>org.seleniumhq.selenium</groupId>
    <artifactId>selenium-java</artifactId>
    <version>4.16.1</version>
    <scope>test</scope>
</dependency>
```

### 2. 配置文件

#### Maven 路径配置
创建项目根目录的 `.maven-path.txt` 文件：
```
D:\apache-maven-3.9.11-bin\apache-maven-3.9.11\bin\mvn.cmd
```

#### 测试环境配置
创建 `src/test/resources/application-test.yml`：
```yaml
spring:
  datasource:
    url: jdbc:mysql://localhost:3306/ry_test?useUnicode=true&characterEncoding=utf8
    username: root
    password: your_password
```

### 3. 使用方法

#### 方式一：使用斜杠命令（推荐）

**生成单个类的测试**
```
/test-gen --path com/ruoyi/web/controller/example/ProductController --type unit
```

**生成所有类型测试**
```
/test-gen --path com/ruoyi/web/controller/example/ProductController --type all
```

**自动模式运行（无需手动登录）**
```
/test-gen --path com/ruoyi/web/controller/example/ProductController --interactive false
```

**指定测试用例数量**
```
/test-gen --path com/ruoyi/web/controller/example/ProductController --scenarios 15
```

#### 方式二：使用 Mode
直接切换到 `test-generator` Mode，然后描述你的测试需求，AI 会自动理解并生成测试代码。

### 4. 执行测试

#### Windows 环境
```bash
# 使用修复版脚本
run_test_fixed.bat
```

#### Linux/Mac 环境
```bash
# 执行测试脚本
chmod +x run_test.sh
./run_test.sh
```

#### Maven 命令
```bash
# 清理并执行测试
mvn clean test -Dmaven.test.failure.ignore=true

# 生成 HTML 报告
mvn surefire-report:report-only
mvn site -DgenerateReports=false
```

## 测试报告

### 报告位置
- **HTML 报告**：`target/site/test-report.html`
- **XML 报告**：`target/surefire-reports/`
- **详细日志**：`target/test-logs/`

### 查看报告
```bash
# Windows
start target\site\test-report.html

# Linux/Mac
open target/site/test-report.html
```

## 项目结构

```
src/test/java/com/ruoyi/
├── test/
│   ├── frontend/           # 前端功能测试
│   │   └── FrontendFunctionalTest.java
│   └── integration/        # 后端集成测试
│       ├── ApiIntegrationTest.java
│       └── InteractiveLoginHelper.java
└── web/controller/         # 控制器单元测试
    └── example/
        └── ProductControllerTest.java

src/test/resources/
├── application-test.yml    # 测试环境配置
├── test-schema.sql         # 测试数据库结构
└── test-data.sql           # 测试数据
```

## 测试用例规范

### 前端测试用例
- 编号：TC101, TC102, ...
- 覆盖场景：
  - 正常功能验证
  - 边界场景验证（空值、错误输入等）
  - 用户交互验证
  - 页面导航验证

### 后端API测试用例
- 编号：TC001, TC002, ...
- 覆盖场景：
  - 成功请求
  - 异常请求（错误参数、重复数据等）
  - 鉴权通过验证
  - 无权限验证

### 单元测试用例
- 命名：test[功能名][场景]
- 覆盖场景：
  - 正常业务流程
  - 边界条件
  - 异常处理
  - 数据验证

## 配置说明

### 测试数据库
```yaml
# 创建测试数据库
CREATE DATABASE ry_test CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

# 导入测试数据
mysql -u root -p ry_test < src/test/resources/test-schema.sql
mysql -u root -p ry_test < src/test/resources/test-data.sql
```

### WebDriver 配置
```bash
# EdgeDriver 下载地址
https://developer.microsoft.com/en-us/microsoft-edge/tools/webdriver/

# 配置系统环境变量
set PATH=D:\edgedriver_win64;%PATH%
```

## 高级用法

### 1. 自定义测试数据
编辑 `test-data.sql` 文件，添加自定义测试数据。

### 2. 跳过交互登录
在 `application-test.yml` 中添加：
```yaml
test:
  interactive:
    login: false
```

### 3. 配置测试超时
```java
@Test
@Timeout(value = 5, unit = TimeUnit.SECONDS)
void testQuickOperation() {
    // 测试代码
}
```

### 4. 并行执行测试
在 `pom.xml` 中配置：
```xml
<plugin>
    <groupId>org.apache.maven.plugins</groupId>
    <artifactId>maven-surefire-plugin</artifactId>
    <configuration>
        <parallel>methods</parallel>
        <threadCount>4</threadCount>
    </configuration>
</plugin>
```

## 故障排除

### 问题：找不到 Maven
**解决方案**：
1. 检查 `.maven-path.txt` 文件是否存在
2. 确认 Maven 安装路径正确
3. 或使用 Maven Wrapper（`mvnw.cmd`）

### 问题：找不到 WebDriver
**解决方案**：
1. 下载对应版本的 WebDriver
2. 配置 WebDriver 路径到系统 PATH
3. 或在测试代码中指定路径

### 问题：测试被阻塞
**解决方案**：
1. 检查是否启用了交互式登录
2. 在浏览器窗口中手动完成登录
3. 在终端按任意键继续
4. 或使用 `--interactive false` 参数

### 问题：数据库连接失败
**解决方案**：
1. 确认 MySQL 服务已启动
2. 检查 `application-test.yml` 中的数据库配置
3. 确认测试数据库 `ry_test` 已创建
4. 导入测试数据库结构和数据

### 问题：测试报告为空
**解决方案**：
1. 确认测试已执行完成
2. 检查控制台是否有编译错误
3. 确认 `target/surefire-reports/` 目录下有 XML 文件
4. 重新运行报告生成命令

## 最佳实践

1. **测试独立性** - 每个测试用例应独立运行，不依赖其他测试
2. **数据隔离** - 使用测试专用数据库，每次测试后清理数据
3. **快速反馈** - 单元测试应快速执行（< 1秒/测试）
4. **清晰命名** - 使用描述性的测试方法名和 DisplayName
5. **及时更新** - 业务代码变更时同步更新测试
6. **覆盖率目标** - 代码覆盖率 > 80%
7. **CI/CD 集成** - 将测试集成到持续集成流程中

## 贡献指南

欢迎贡献测试用例和改进建议！

### 提交测试用例
1. 遵循项目代码结构
2. 确保测试通过
3. 添加必要的注释和文档
4. 更新测试报告

### 报告问题
请提交 Issue，包含：
- 问题描述
- 复现步骤
- 错误日志
- 系统环境信息

## 许可证

本项目遵循项目的开源许可证。

## 联系方式

如有问题或建议，请通过 Issue 联系。

## 更新日志

### v1.0.0 (2026-01-02)
- 初始版本发布
- 支持前端、后端、单元测试生成
- 交互式登录功能
- 自动化测试报告生成